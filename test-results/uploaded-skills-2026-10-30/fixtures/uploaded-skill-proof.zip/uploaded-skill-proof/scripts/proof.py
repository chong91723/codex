import argparse,hashlib,json,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--text',required=True);p.add_argument('--output',required=True);p.add_argument('--hold',type=int,default=0);a=p.parse_args()
assert 0<=a.hold<=20
time.sleep(a.hold)
r={'marker':'UPLOAD_SKILL_OK','text':a.text,'sha256':hashlib.sha256(a.text.encode()).hexdigest(),'character_count':len(a.text)}
target=Path(a.output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(r,ensure_ascii=False));print(json.dumps(r,ensure_ascii=False))
