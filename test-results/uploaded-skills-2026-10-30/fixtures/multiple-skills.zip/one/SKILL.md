---
name: uploaded-skill-proof
description: Verify an explicitly selected uploaded local skill package by reading its reference and running its supplied local Python proof script. Use only when the user asks for this acceptance proof.
---
# Local uploaded skill proof
Read `references/format.md` before executing. Run `scripts/proof.py` with the exact user-supplied text and workspace output path. Use the requested hold window only for acceptance, not business computation. Do not download packages or use the network. Do not alter the skill package. Report only the actual marker and output path after the command completes. No memory writes.
